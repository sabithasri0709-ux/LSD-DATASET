Augmented cattle image dataset

Classes
- TICK_FLIES
- MUD
- SNOW
- LSD (lumpy skin disease)

Contents
Each class folder contains source images and three derived variants: a horizontal flip, a small 7-degree rotation, and a mild brightness/contrast adjustment. Filenames retain the class and source index. manifest.csv maps each image to its class, source media file, and transformation.

Counts
- TICK_FLIES: 75 source images, 300 files including variants
- MUD: 121 source images, 484 files including variants
- SNOW: 83 source images, 332 files including variants
- LSD: 166 source images, 664 files including variants
- Total: 445 source images and 1,335 augmented images (1,780 files total).

Important for model evaluation
Split the original source images into training, validation, and test sets first. Generate/use augmented copies only in the training split. Keep all variants of a source image in the same split to avoid data leakage.

Notes
The class assignment follows the image sections/order in the supplied combined document: tick/flies, mud, snow, then the final LSD image group. Augmentation is limited to geometric and mild illumination changes intended to keep the class label intact.

This archive is part2 of 2. Classes included: SNOW, LSD.
